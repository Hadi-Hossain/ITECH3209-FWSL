
     <div class="header-wrapper">
         <header>
          <div class="container">
            <div class="logo-container">
                <a href="index-2.html"  title="Tech School">
                    <img src="<?php echo e(asset('contents/website/assests/images/logo-1.png')); ?>" alt="Tech School">
                </a>
                <span class="tag-line">Ballarat Tech School</span>
            </div>         <!-- Start of Main Navigation -->
                <nav class="main-nav">
                        <div class="menu-top-menu-container">
                                <ul id="menu-top-menu" class="clearfix">
                                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                        <li><a href="<?php echo e(url('/synthesis')); ?>">IT synthesis</a></li>
                                        <li class="current-menu-item"><a href="<?php echo e(url('/homearticle')); ?>">Health-Science</a></li>
                                        <li><a href="<?php echo e(url('/homecat')); ?>">IT synthesis</a></li>
                                        <li><a href="<?php echo e(url('/single')); ?>">FAQs</a></li>
                                        <li><a href="<?php echo e(url('/element')); ?>">Element</a></li>
                                        <li><a href="<?php echo e(url('/article')); ?>">Article</a>

                                        </li>
                                        <li><a href="<?php echo e(url('/note')); ?>">Note</a>
                                        </li>
                                        <?php if(@Auth::user()->id !=NUll): ?>
                                        <li class="active-menu"><a href="">DashBoard</a>
                                            <ul class="sub-menu">
                                                <li style="color: red">My Profile</li>
                                                <li>My Jernal</li>
                                                <li>LOGOUT</li>
                                            </ul>
                                        </li>
                                        <?php else: ?>
                                        <li><a href="<?php echo e(url('/student/login')); ?>">Login</a></li>
                                        <?php endif; ?>
                                </ul>
                        </div>
                </nav>
            </div>
        </header>
    </div>


<?php /**PATH C:\xampp\htdocs\tech_school\tech_school\resources\views/layouts/website/header.blade.php ENDPATH**/ ?>