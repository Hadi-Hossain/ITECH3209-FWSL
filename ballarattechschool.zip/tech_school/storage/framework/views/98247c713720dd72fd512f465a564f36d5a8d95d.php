     <!-- Start of Footer -->
     <footer id="footer-wrapper">
        <div id="footer" class="container">
                <div class="row">

                        <div class="span3">
                                <section class="widget">
                                        <h3 class="title">Spare footer </h3>
                                        <div class="textwidget">
                                                <p> </p>
                                                <p> </p>
                                        </div>
                                </section>
                        </div>

                        <div class="span3">
                                <section class="widget"><h3 class="title">Categories</h3>
                                        <ul>
                                                <li><a href="#" title="Lorem ipsum dolor sit amet,">IT synthesis</a> </li>
                                                <li><a href="#" title="Lorem ipsum dolor sit amet,">Health-Science</a></li>
                                                <li><a href="#" title="Lorem ipsum dolor sit amet,">Food and Fibre</a></li>
                                                <li><a href="#" title="Lorem ipsum dolor sit amet, ">New-engry</a></li>
                                                <li><a href="#" title="Lorem ipsum dolor sit amet,">Advanced-manufacturing</a></li>
                                                <li><a href="#" title="Lorem ipsum dolor sit amet,">STEAM</a></li>
                                                <li><a href="#" title="Lorem ipsum dolor sit amet, ">About</a></li>
                                        </ul>
                                </section>
                        </div>

                        <div class="span3">
                                <section class="widget">
                                        <h3 class="title">Latest Tweets</h3>
                                        <div id="twitter_update_list">
                                                <ul>
                                                        <li>No Tweets loaded !</li>
                                                </ul>
                                        </div>

                                </section>
                        </div>

                        <div class="span3">
                                <section class="widget">
                                        <h3 class="title">Flickr Photos</h3>
                                        <div class="flickr-photos" id="basicuse">
                                        </div>
                                </section>
                        </div>

                </div>
        </div>
        <!-- Footer Bottom -->
        <div id="footer-bottom-wrapper">
                <div id="footer-bottom" class="container">
                        <div class="row">
                                <div class="span6">
                            </div>
                                <div class="span6">
                                        <!-- Social Navigation -->
                                        <ul class="social-nav clearfix">
                                                <li class="linkedin"><a target="_blank" href="#"></a></li>
                                                <li class="stumble"><a target="_blank" href="#"></a></li>
                                                <li class="google"><a target="_blank" href="#"></a></li>
                                                <li class="deviantart"><a target="_blank" href="#"></a></li>
                                                <li class="flickr"><a target="_blank" href="#"></a></li>
                                                <li class="skype"><a target="_blank" href="skype:#?call"></a></li>
                                                <li class="rss"><a target="_blank" href="#"></a></li>
                                                <li class="twitter"><a target="_blank" href="#"></a></li>
                                                <li class="facebook"><a target="_blank" href="#"></a></li>
                                        </ul>
                                </div>
                        </div>
                </div>
        </div>
        <!-- End of Footer Bottom -->

</footer>
<?php /**PATH C:\xampp\htdocs\tech_school\tech_school\resources\views/layouts/website/footer.blade.php ENDPATH**/ ?>