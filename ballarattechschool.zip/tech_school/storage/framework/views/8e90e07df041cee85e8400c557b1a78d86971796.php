<?php $__env->startSection('title', 'Customer Signup'); ?>
<?php $__env->startSection('content'); ?>
<div class="login-area-wrapper">
    <div class="cotn_principal">
      <div class="cont_centrar">
        <div class="cont_login">
          <div class="cont_forms_two">
            <form class="form pt-3" method="post" action="<?php echo e(url('/student/signup-store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <h2 style="padding-left: 102px;">SING-UP</h2>
                <div class="form-group" style="padding-left: 37px;">
                    <label>Name</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon11"><i class="ti-user"></i></span>
                        </div>
                        <input type="text" class="form-control" placeholder="Name" name="name" value="<?php echo e(old('name')); ?>" required>

                        <?php if($errors->has('name')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group" style="padding-left: 37px;">
                    <label for="exampleInputEmail1">Email address</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon22"><i class="ti-email"></i></span>
                        </div>
                        <input type="email" class="form-control" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">

                        <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group" style="padding-left: 37px;">
                    <label>Phone</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon11"><i class="ti-user"></i></span>
                        </div>
                        <input type="text" class="form-control" placeholder="phone" name="phone" value="<?php echo e(old('phone')); ?>">

                        <?php if($errors->has('phone')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('phone')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group" style="padding-left: 37px;">
                    <label>User Name</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon11"><i class="ti-user"></i></span>
                        </div>
                        <input type="text" class="form-control" placeholder="username" name="username" value="<?php echo e(old('username')); ?>">

                        <?php if($errors->has('username')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('username')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group" style="padding-left: 37px;">
                    <label>Address</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon11"><i class="ti-user"></i></span>
                        </div>
                        <input type="text" class="form-control" placeholder="address" name="address" value="<?php echo e(old('address')); ?>">

                        <?php if($errors->has('address')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('address')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group" style="padding-left: 37px;">
                    <label>Password</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon33"><i class="ti-lock"></i></span>
                        </div>
                        <input type="password" class="form-control" placeholder="Password" name="password">

                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group" style="padding-left: 37px;">
                    <label>Confirm Password</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon4"><i class="ti-lock"></i></span>
                        </div>
                        <input type="password" class="form-control" placeholder="Confirm Password"
                        aria-label="Password" name="password_confirmation">
                    </div>
                </div>
                <div class="form-group" style="padding-left: 37px;">
                    <label>Photo</label>
                    <div class="custom-file mb-3">
                        <input type="file" name="image" class="custom-file-input" id="customFile">
                        <?php if($errors->has('image')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('image')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div style="padding-left: 36px;padding-top:18px;">
                    <button class="btn_sign_up" type="submit" class="btn btn-primary"><?php echo e(__('Register')); ?></button>
                </div>
                <div style="padding-left: 36px;padding-top:18px;">
                    have you any account?<a style="color:blue;font-weight:700" href="<?php echo e(route('student.login')); ?>">Signin here</a>
                </div>
            </form>

          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.website.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\tech_school\resources\views/website/student/register.blade.php ENDPATH**/ ?>