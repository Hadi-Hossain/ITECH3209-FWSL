<?php $__env->startSection('title', 'Learn'); ?>
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('contents/admin/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Bread crumb and right sidebar toggle -->

    <?php $__env->startComponent('admin.dashboard.breadcumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(url('admin/learningjernal')); ?>">Jernal Information</a></li>
    <?php echo $__env->renderComponent(); ?>

    <!-- End Bread crumb and right sidebar toggle -->
    <div class="page-content container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="material-card card">
                    <div class="card-header">
						<div class="pull-left">
							<h6 class="card-title mt-1">Jernal</h6>
						</div>

					</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <h2><?php echo e($data->description); ?></h2>
                            <p>
                                <iframe src="<?php echo e(asset('image/pdf/')); ?>/<?php echo e($data->file); ?>" frameborder="0" style="width: 600px;height:400px"></iframe>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('contents/admin/assets/extra-libs/DataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('contents/admin/dist/js/pages/datatable/datatable-basic.init.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tech_school\tech_school\resources\views/admin/pdf/pdf.blade.php ENDPATH**/ ?>