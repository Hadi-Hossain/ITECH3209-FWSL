<?php $__env->startSection('title', 'Contact Messages'); ?>
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('contents/admin/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Bread crumb and right sidebar toggle -->

    <?php $__env->startComponent('admin.dashboard.breadcumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(url('admin/contacts')); ?>">Contact Messages</a></li>
    <?php echo $__env->renderComponent(); ?>

    <!-- End Bread crumb and right sidebar toggle -->
    <div class="page-content container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="material-card card">
                    <div class="card-header">
						<div class="pull-left">
							<h6 class="card-title mt-1">Contact Messages</h6>
						</div>
					</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="zero_config" class="table table-striped border">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Created Name:</th>
                                        <th>Jernal Name</th>
                                        <th>Description</th>
                                        <th>Image</th>
                                        <th>File</th>
                                        <th>download</th>
                                        <th>Status</th>
                                        <th>Mark</th>
                                        <th>Time</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $contactmessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$contactMessage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="<?php echo e($contactMessage->status == 0 ? 'unreaded' : ''); ?>">
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e($contactMessage->user->name); ?></td>
                                            <td><?php echo e($contactMessage->jernal->jernal_name); ?></td>
                                            <td><?php echo e(str_limit($contactMessage->description, 15)); ?></td>
                                            <td>
                                            <img width="30" src="<?php echo e(asset('image/student/')); ?>/<?php echo e($contactMessage->image); ?>" alt="">

                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('admin/filed/'.$contactMessage->id)); ?>">View</a>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('admin/download/'.$contactMessage->file)); ?>">Download</a>
                                            </td>
                                            <?php if($contactMessage->status == ! NULL): ?>
                                            <td><label class="badge badge-success badge-pill">Active</label></td>
                                            <?php else: ?>
                                            <td><label class="badge badge-warning badge-pill">Inactive</label></td>
                                            <?php endif; ?>
                                            <?php if($contactMessage->mark==1): ?>
                                           <td> <a href="<?php echo e(url('admin/subscriber-status/'.$contactMessage->id.'/0')); ?>" class="btn-success btn-circle btn-sm"><i class="fas fa-check" ></i>pass</a></td>
                                            <?php else: ?>
                                           <td>
                                            <a href="<?php echo e(url('admin/subscriber-status/'.$contactMessage->id.'/1')); ?>" class="btn-danger btn-circle btn-sm"><i class="fas fa-times">fail</i></a>
                                           </td>
                                            <?php endif; ?>

                                            <td><?php echo e($contactMessage->created_at->diffForHumans()); ?></td>
                                            <td>
                                                <a href="<?php echo e(url('admin/contacts/'. $contactMessage->id)); ?>"><button class="btn btn-info btn-circle btn-sm"><i class="mdi mdi-eye"></i></button></a>

                                                <button data-url="<?php echo e(url('admin/contacts/'.$contactMessage->id)); ?>" class="btn-delete btn btn-danger btn-circle btn-sm" data-toggle="modal" data-target="#deleteModal"><i class="mdi mdi-delete"></i></button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form  method="post" id="delete-form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <div class="modal-header">
                            <h4 class="modal-title" id="exampleModalLabel1">Are you sure to delete?</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancle</button>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('contents/admin/assets/extra-libs/DataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('contents/admin/dist/js/pages/datatable/datatable-basic.init.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\tech_school\resources\views/admin/contact/index.blade.php ENDPATH**/ ?>