<?php $__env->startSection('title', $contactmessage->subject); ?>
<?php $__env->startSection('content'); ?>
    <!-- Bread crumb and right sidebar toggle -->

    <?php $__env->startComponent('admin.dashboard.breadcumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(url('admin/contacts')); ?>">Messages</a></li>
    <li class="breadcrumb-item active" aria-current="page">View</li>
    <?php echo $__env->renderComponent(); ?>

    <!-- End Bread crumb and right sidebar toggle -->
    <div class="page-content container-fluid">
        <div class="row justify-content-center">
            <div class="col-8">
                <div class="mail-details bg-white">
                    <div class="card-body border-bottom">
                        <h4 class="mb-0 mt-1 pull-left">Contact Message</h4>
                        <a href="<?php echo e(url('admin/contacts')); ?>" class="pull-right btn btn-outline-info btn-sm"><i class="mdi mdi-arrow-left"></i>Back</a>
                        <div class="clearfix"></div>
                    </div>
                    <div class="card-body border-bottom">
                        <div class="d-flex no-block align-items-center mb-5">

                            <div class="">
                                <h5 class="mb-0 font-16 font-medium"><?php echo e($contactmessage->jernal->jernal_name); ?></h5>
                                <span><?php echo e($contactmessage->description); ?></span>
                            </div>
                        </div>
                        <img width="100px" src="<?php echo e(asset('image/student/')); ?>/<?php echo e($contactmessage->image); ?>" alt="">
                        <h4 class="mb-3"><?php echo e($contactmessage->subject); ?></h4>
                        <p><?php echo e($contactmessage->message); ?></p>
                        <h2><a href="<?php echo e(url('admin/filed/'.$contactmessage->id)); ?>">Project File</a></h2>
                        <h2> <a href="<?php echo e(url('admin/download/'.$contactmessage->file)); ?>">Download</a></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tech_school\tech_school\resources\views/admin/contact/show.blade.php ENDPATH**/ ?>