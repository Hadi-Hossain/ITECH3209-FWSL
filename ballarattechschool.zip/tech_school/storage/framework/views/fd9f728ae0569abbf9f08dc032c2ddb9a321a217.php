<?php $__env->startSection('title', 'Course'); ?>
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('contents/admin/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Bread crumb and right sidebar toggle -->

    <?php $__env->startComponent('admin.dashboard.breadcumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(url('admin/course')); ?>">Course Information</a></li>
    <?php echo $__env->renderComponent(); ?>

    <!-- End Bread crumb and right sidebar toggle -->
    <div class="page-content container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="material-card card">
                    <div class="card-header">
						<div class="pull-left">
							<h6 class="card-title mt-1">Course</h6>
						</div>
						<div class="pull-right">
                            <a href="<?php echo e(url('/admin/course/create')); ?>" class="btn btn-outline-info btn-sm"><i class="mdi mdi-plus-circle"></i> Create Course</a>
						</div>
					</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="zero_config" class="table table-striped border">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Course Name</th>
                                        <th>CourseCode</th>
                                        <th>Course Code</th>
                                        <th>Text</th>
                                        <th>Assessment</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($course->id); ?></td>
                                            <td><?php echo e($course->name); ?></td>
                                            <td><?php echo e($course->name); ?><?php echo e($course->code); ?></td>
                                            <td><?php echo e($course->code); ?></td>
                                            <td>
                                                <?php echo str_limit($course->text, 20); ?>

                                            </td>
                                            <td><?php echo e($course->assessment); ?></td>
                                            <?php if($course->status == 1): ?>
                                            <td><label class="badge badge-success badge-pill">Active</label></td>
                                            <?php else: ?>
                                            <td><label class="badge badge-warning badge-pill">Inactive</label></td>
                                            <?php endif; ?>
                                            <td>
                                                <a href="<?php echo e(url('admin/course/'. $course->id.'/edit')); ?>"><button class="btn btn-success btn-circle btn-sm"><i class="mdi mdi-pencil"></i></button></a>
                                                <button data-url="<?php echo e(url('admin/course/'.$course->id)); ?>" class="btn-delete btn btn-danger btn-circle btn-sm" data-toggle="modal" data-target="#deleteModal"><i class="mdi mdi-delete"></i></button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form  method="post" id="delete-form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <div class="modal-header">
                            <h4 class="modal-title" id="exampleModalLabel1">Are you sure to delete?</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancle</button>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('contents/admin/assets/extra-libs/DataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('contents/admin/dist/js/pages/datatable/datatable-basic.init.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\tech_school\resources\views/admin/course/index.blade.php ENDPATH**/ ?>