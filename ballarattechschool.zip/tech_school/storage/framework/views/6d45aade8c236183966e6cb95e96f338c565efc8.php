<footer class="footer text-center">
    &copy All Rights Reserved by RedLine. Developed by
    <a href="#">Creative Shaper</a>.
</footer>
<?php /**PATH F:\xampp\htdocs\tech_school\resources\views/layouts/admin_layout/admin_footer.blade.php ENDPATH**/ ?>