<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
        <head>
                <!-- META TAGS -->
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
                <title>::TECH SCHOOL::</title>
                <link rel="stylesheet" href="<?php echo e(asset('contents/website/assests/css/style.css')); ?>"/>
                <link rel="stylesheet" id="bootstrap-css-css"  href="<?php echo e(asset('contents/website/assests/css/bootstrap5152.css')); ?>" type="text/css" media="all" />
                <link rel="stylesheet" id="responsive-css-css"  href="<?php echo e(asset('contents/website/assests/css/responsive5152.css?ver=1.0')); ?>" type="text/css" media="all" />
                <link rel="stylesheet" id="main-css-css"  href="<?php echo e(asset('contents/website/assests/css/main5152.css?ver=1.0')); ?>" type="text/css" media="all" />
      <head>
          <body>

            <?php echo $__env->make('layouts.website.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('layouts.website.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <script type="text/javascript" src="<?php echo e(asset('contents/website/assests/js/custom.js')); ?>"></script>
            <script type="text/javascript" src="<?php echo e(asset('contents/website/assests/js/jflickrfeed.js')); ?>"></script>
            <script type="text/javascript" src="<?php echo e(asset('contents/website/assests/js/jquery.form.js')); ?>"></script>
            <script type="text/javascript" src="<?php echo e(asset('contents/website/assests/js/jquery.easing.1.3.js')); ?>"></script>
            <script type="text/javascript" src="<?php echo e(asset('contents/website/assests/js/jquery.liveSearch.js')); ?>"></script>
            <script type="text/javascript" src="<?php echo e(asset('contents/website/assests/js/index.js')); ?>"></script>
          </body>
        </html>
<?php /**PATH F:\xampp\htdocs\tech_school\resources\views/layouts/website/website.blade.php ENDPATH**/ ?>