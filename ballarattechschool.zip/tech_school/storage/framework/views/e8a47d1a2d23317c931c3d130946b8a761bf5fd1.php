<?php $__env->startSection('title', 'Students'); ?>
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('contents/admin/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Bread crumb and right sidebar toggle -->

    <?php $__env->startComponent('admin.dashboard.breadcumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(url('admin/student')); ?>">Students</a></li>
    <?php echo $__env->renderComponent(); ?>

    <!-- End Bread crumb and right sidebar toggle -->
    <div class="page-content container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="material-card card">
                    <div class="card-header">
						<div class="pull-left">
							<h6 class="card-title mt-1">Students</h6>
						</div>
					</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="zero_config" class="table table-striped border">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>phone</th>
                                        <th>Address</th>
                                        <th>Resigtration Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                       $created =new Carbon\Carbon($student->created_at);
                                       $now=Carbon\Carbon::now();
                                       $difference=($created->diff($now)->days<1)?'today':$created->diffForHumans($now);

                                    ?>
                                        <tr>
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e($student->name); ?></td>
                                            <td><?php echo e($student->email); ?></td>
                                            <td><?php echo e($student->phone); ?></td>
                                            <td><?php echo e(str_limit($student->address, 20)); ?></td>
                                            <td><?php echo e($difference); ?></td>
                                            <?php if($student->deleted_at == null): ?>
                                            <td><label class="badge badge-success badge-pill">Active</label></td>
                                            <?php else: ?>
                                            <td><label class="badge badge-inverse badge-pill">Inactive</label></td>
                                            <?php endif; ?>
                                            <td>
                                                <a href="<?php echo e(url('admin/student/'. $student->id)); ?>"><button class="btn btn-info btn-circle btn-sm"><i class="mdi mdi-eye"></i></button></a>
                                                <button data-url="<?php echo e(url('admin/student/'.$student->id)); ?>" class="btn-delete btn btn-danger btn-circle btn-sm" data-toggle="modal" data-target="#deleteModal"><i class="mdi mdi-delete"></i></button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form  method="post" id="delete-form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <div class="modal-header">
                            <h4 class="modal-title" id="exampleModalLabel1">Are you sure to delete?</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancle</button>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('contents/admin/assets/extra-libs/DataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('contents/admin/dist/js/pages/datatable/datatable-basic.init.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tech_school\tech_school\resources\views/admin/student/index.blade.php ENDPATH**/ ?>