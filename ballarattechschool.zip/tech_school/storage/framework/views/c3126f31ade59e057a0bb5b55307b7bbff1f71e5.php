<?php $__env->startSection('title', 'Email Verification'); ?>
<?php $__env->startSection('content'); ?>

<div class="login-area-wrapper">
    <div class="cotn_principal">
      <div class="cont_centrar">
        <div class="cont_login">
          <div class="cont_forms">
                <form method="POST" action="<?php echo e(route('verify.store')); ?>">
                    <?php echo csrf_field(); ?>
                        <h2 style="padding-left: 102px;">Verify</h2>
                        <div style="padding-left: 47px;padding-top:18px;">
                            <input name="email" type="text" placeholder="Email" value="<?php echo e(old('email')); ?>" required="">
                        </div>
                        <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                        <?php endif; ?>
                        <div  style="padding-left: 47px;">
                            <input name="code" placeholder="Code" required="" type="text" required="">
                        </div>

                        <?php if($errors->has('code')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('code')); ?></strong>
                        </span>
                        <?php endif; ?>
                        <div style="padding-left: 36px;padding-top:18px;">
                            <button class="btn_login" type="submit" class="btn btn-primary"><?php echo e(__('Verify')); ?></button>
                        </div>
                </form>
          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

 <!-- Start of login Wrapper -->

<?php echo $__env->make('layouts.website.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tech_school\tech_school\resources\views/website/student/verify.blade.php ENDPATH**/ ?>