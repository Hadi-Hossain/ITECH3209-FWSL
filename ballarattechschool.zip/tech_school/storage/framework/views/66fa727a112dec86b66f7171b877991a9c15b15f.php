<?php $__env->startSection('title', $course->name); ?>

<?php $__env->startSection('content'); ?>
    <!-- Bread crumb and right sidebar toggle -->

    <?php $__env->startComponent('admin.dashboard.breadcumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(url('admin/course')); ?>">Course</a></li>
    <li class="breadcrumb-item active" aria-current="page">edit</li>
    <?php echo $__env->renderComponent(); ?>

    <!-- End Bread crumb and right sidebar toggle -->
    <div class="page-content container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
						<div class="pull-left">
							<h6 class="card-title mt-1">Update Course</h6>
						</div>
						<div class="pull-right">
                            <a href="<?php echo e(url('/admin/course')); ?>" class="btn btn-outline-info btn-sm"><i class="mdi mdi-arrow-left"></i> Back</a>
						</div>
					</div>
                    <div class="card-body">
                        <form class="form pt-3" method="post" action="<?php echo e(url('admin/course/'.$course->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>

                            <div class="form-group">
                                <label>Course Name</label>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" placeholder="name" name="name" value="<?php echo e($course->name); ?>">

                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Code</label>
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control" placeholder="code" name="code" value="<?php echo e($course->code); ?>">

                                    <?php if($errors->has('code')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('code')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Assessment</label>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" placeholder="Button Text" name="assessment" value="<?php echo e($course->assessment); ?>">
                                    <?php if($errors->has('assessment')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('assessment')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <h5 class="card-title mt-3">Description</h5>
                                <textarea name="text" id="description"><?php echo e($course->text); ?></textarea>
                                <?php if($errors->has('text')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('text')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-success mr-2">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('contents/admin/assets/libs/tinymce/tinymce.min.js')); ?>"></script>
<script>
    $(function () {
        //TinyMCE
        tinymce.init({
            selector: "#description",
            theme: "modern",
            height: 300,
            plugins: [
                'advlist autolink lists link image charmap print preview hr anchor pagebreak',
                'searchreplace wordcount visualblocks visualchars code fullscreen',
                'insertdatetime media nonbreaking save table contextmenu directionality',
                'emoticons template paste textcolor colorpicker textpattern imagetools'
            ],
            toolbar1: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
            toolbar2: 'print preview media | forecolor backcolor emoticons',
            image_advtab: true
        });
        tinymce.suffix = ".min";
        tinyMCE.baseURL = '<?php echo e(asset('contents/admin/assets/libs/tinymce')); ?>';
    });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\tech_school\resources\views/admin/course/edit.blade.php ENDPATH**/ ?>