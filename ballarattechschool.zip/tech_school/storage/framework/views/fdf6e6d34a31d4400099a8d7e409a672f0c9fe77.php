<?php $__env->startSection('title', 'School Create'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Bread crumb and right sidebar toggle -->

    <?php $__env->startComponent('admin.dashboard.breadcumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(url('admin/school')); ?>">School</a></li>
    <li class="breadcrumb-item active" aria-current="page">Create</li>
    <?php echo $__env->renderComponent(); ?>

    <!-- End Bread crumb and right sidebar toggle -->
    <div class="page-content container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
						<div class="pull-left">
							<h6 class="card-title mt-1">Create Category</h6>
						</div>
						<div class="pull-right">
                            <a href="<?php echo e(url('/admin/school')); ?>" class="btn btn-outline-info btn-sm"><i class="mdi mdi-arrow-left"></i> Back</a>
						</div>
					</div>
                    <div class="card-body">
                        <form class="form pt-3" method="post" action="<?php echo e(url('admin/school')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>School Name</label>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" placeholder="SchoolName" name="name" value="<?php echo e(old('name')); ?>">
                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>User Name</label>
                                <select class="form-control custom-select" name="user">
                                    <option>Select User Name</option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Course Name</label>
                                <select class="form-control custom-select" name="course">
                                    <option>Select Course</option>
                                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-success mr-2">CREATE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('contents/admin/dist/js/ajax.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\tech_school\resources\views/admin/school/create.blade.php ENDPATH**/ ?>