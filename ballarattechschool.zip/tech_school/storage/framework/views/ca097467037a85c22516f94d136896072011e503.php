<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<style type="text/css">
    .prof li{
        background-color: darkorange;
        padding: 7px;
        margin: 4px;
        border-radius: 15px;
        list-style-type: none;
        width: 130px;
    }
    .prof li a{
        padding-left: 15px;
    }
    .update{
        position: relative;
        top: -137px;
        left: 200px;
    }
    .pull-right{
        position: relative;
    top: -151px;
    }
</style>

<section style="padding-left: 50px">
    <div class="col-lg-3 col-md-4 col-xs-12 align-self-center">
        <h5 class="font-medium text-uppercase mb-0">User Name : <strong style="color: hotpink;font-weight:700"><?php echo e(Auth::user()->name); ?></strong></h5>
        <h5 class="font-medium text-uppercase mb-0">UserType : <strong style="color: hotpink;font-weight:700"><?php echo e(Auth::user()->role->role_name); ?></strong></h5>
    </div>
</section>
<section id="user_dashboard_main_section">
    <div class="container">
        <div class="row" style="padding: 15px 0px 15px 0px">
            <div class="col-xl-2 col-md-2">
                <ul class="prof">
                    <li class=""><a href="<?php echo e(url('student/dashboard')); ?>"><i class="fas fa-home"></i> My Profile</a></li>
                    <li class=""><a href="<?php echo e(url('student/student-index')); ?>"><i class="fas fa-shopping-cart"></i>My Jurnal</a></li>
                    <li class=""><a href="<?php echo e(url('student/student-password-change')); ?>"><i class="fas fa-cog"></i> Password Change</a></li>
                    <li> <a style="font-size:15px;color:black;font-weight:600" href="<?php echo e(route('logout')); ?>"onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                        <i class="mdi mdi-power"></i><span class="hide-menu">logout</span></a>
                      </li>
                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                          <?php echo csrf_field(); ?>
                    </form>
                </ul>
            </div>
            <div class="pull-right">
                <a href="<?php echo e(url('/student/student-create')); ?>" class="btn btn-danger btn-sm">Send Jernals</a>

            </div>
            <div class="col-md-10">
                <div class="card-body update">
                    <div class="table-responsive">
                        <table id="zero_config" class="table table-striped border">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Jernal Name</th>
                                    <th>Description</th>
                                    <th>Image</th>
                                    <th>File</th>
                                    <th>download</th>
                                    <th>Status</th>
                                    <th>Marks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sendfile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sendfile->id); ?></td>
                                        <td><?php echo e($sendfile->jernal->jernal_name); ?></td>
                                        <td><?php echo e($sendfile->description); ?></td>
                                        <td>
                                            <img width="30" src="<?php echo e(asset('image/student/')); ?>/<?php echo e($sendfile->image); ?>" alt="">

                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('student/filed/'.$sendfile->id)); ?>">View</a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('student/download/'.$sendfile->file)); ?>">Download</a>
                                        </td>
                                        
                                        <?php if($sendfile->status =='1'): ?>
                                        <td><label class="badge badge-success badge-pill">Approved</label></td>
                                        <?php else: ?>
                                        <td><label class="badge badge-warning badge-pill">UnApproved</label></td>
                                        <?php endif; ?>
                                        <?php if($sendfile->mark =='1'): ?>
                                        <td><label class="badge badge-success badge-pill">Pass</label></td>
                                        <?php else: ?>
                                        <td><label class="badge badge-warning badge-pill">Fail</label></td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script type="text/javascript">
$(document).ready(function(){
    $('#image').change(function(e){
        var reader = new FileReader();
        reader.onload=function(e){
            $('#showImage').attr('src,e.target.result');
        }
        reader.readAsDataURL(e.target.files['0']);

    });

});

</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.website.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tech_school\tech_school\resources\views/student/SendFile/index.blade.php ENDPATH**/ ?>