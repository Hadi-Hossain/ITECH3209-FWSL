<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<style type="text/css">
    .prof li{
        background-color: darkorange;
        padding: 7px;
        margin: 4px;
        border-radius: 15px;
        list-style-type: none;
        width: 130px;
    }
    .prof li a{
        padding-left: 15px;
    }
    .update{
        position: relative;
        top: -137px;
        left: 292px;
    }
</style>

<section style="padding-left: 50px">
    <div class="col-lg-3 col-md-4 col-xs-12 align-self-center">
        <h5 class="font-medium text-uppercase mb-0">User Name : <strong style="color: hotpink;font-weight:700"><?php echo e(Auth::user()->name); ?></strong></h5>
        <h5 class="font-medium text-uppercase mb-0">UserType : <strong style="color: hotpink;font-weight:700"><?php echo e($editData->role->role_name); ?></strong></h5>
    </div>
</section>
<section id="user_dashboard_main_section">
    <div class="container">
        <div class="row" style="padding: 15px 0px 15px 0px">
            <div class="col-xl-2 col-md-2">
                <ul class="prof">
                    <li class=""><a href="<?php echo e(url('student/dashboard')); ?>"><i class="fas fa-home"></i> My Profile</a></li>
                    <li class=""><a href="<?php echo e(url('student/student-index')); ?>"><i class="fas fa-shopping-cart"></i>My Jurnal</a></li>
                    <li class=""><a href="<?php echo e(url('student/student-password-change')); ?>"><i class="fas fa-cog"></i> Password Change</a></li>
                    <li> <a style="font-size:15px;color:black;font-weight:600" href="<?php echo e(route('logout')); ?>"onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                        <i class="mdi mdi-power"></i><span class="hide-menu">logout</span></a>
                      </li>
                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                          <?php echo csrf_field(); ?>
                    </form>
                </ul>
            </div>
            <div class="col-md-10">
            <form action="<?php echo e(url('student/student-edit-profile')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-4 update">
                        <label>Full Name</label>
                        <input type="text" name="name" value="<?php echo e($editData->name); ?>" class="form-control">
                        <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-4 update">
                        <label>Email</label>
                        <input type="email" name="email" value="<?php echo e($editData->email); ?>" class="form-control">

                        <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                    </div>
                    <div class="col-md-4 update">
                        <label>Phone</label>
                        <input type="text" name="phone" value="<?php echo e($editData->phone); ?>" class="form-control">
                        <?php if($errors->has('phone')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('phone')); ?></strong>
                        </span>
                    <?php endif; ?>
                    </div>
                    <div class="col-md-4 update">
                        <label>Address</label>
                        <input type="text" name="address" value="<?php echo e($editData->address); ?>" class="form-control">
                    </div>
                    <div class="col-md-4 update">
                        <label>Image</label>
                        <input type="file" name="image" class="form-control" id="image">
                    </div>
                    <div class="col-md-2 update">
                        <img src="<?php echo e((!empty($editData->image))?url('public/image/user/'.$editData->image):url('public/image/no_image.png')); ?>" alt="" id="showImage" style="width:60px;height:40px">
                    </div>
                    <div class="col-md-4 update">
                       <button type="submit" class="btn btn-success">Profile Update</button>
                    </div>
                </div>
            </form>


            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script type="text/javascript">
$(document).ready(function(){
    $('#image').change(function(e){
        var reader = new FileReader();
        reader.onload=function(e){
            $('#showImage').attr('src,e.target.result');
        }
        reader.readAsDataURL(e.target.files['0']);

    });

});

</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.website.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tech_school\tech_school\resources\views/student/dashboard/profileedit.blade.php ENDPATH**/ ?>