<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/','WebsiteController@index')->name('');
Route::get('/element','WebsiteController@element')->name('');
Route::get('/article','WebsiteController@article')->name('');
Route::get('/note','WebsiteController@note')->name('');
Route::get('/homecat','WebsiteController@homecat')->name('');
Route::get('/homearticle','WebsiteController@homearticle')->name('');
Route::get('/synthesis','WebsiteController@synthesis')->name('');
Route::get('/single','WebsiteController@single')->name('');



// Customer login and Register Routes

//vip student
Route::get('/student/login','LearnController@viplogin')->name('student.login');
Route::get('/student/signup','LearnController@vipsinup')->name('student.sinsup');
Route::post('/student/signup-store','LearnController@storesinup')->name('student.signup');
Route::get('/email-verify','LearnController@emailverify')->name('email.verify');
Route::post('/verify-store','LearnController@verifystore')->name('verify.store');

Auth::routes();
Route::group(['as'=>'admin.','prefix'=>'admin','namespace'=>'Admin','middleware'=>['auth','admin']], function (){
    Route::get('dashboard','AdminController@index')->name('dashboard');
    Route::resource('user', 'UserController');
    Route::resource('school', 'SchoolController');
    Route::resource('course', 'CourseController');
    Route::resource('learningjernal', 'learningjernalController');
    Route::resource('recycle/user', 'RecycleUserController');


          // Contact messages routes
    Route::get('contacts','ContactController@index')->name('');
    Route::get('contacts/{id}','ContactController@show')->name('');
    // Route::get('contacts/{mark}','ContactController@mark')->name('');
    Route::delete('contacts/{id}','ContactController@destroy')->name('');
    Route::get('pending','ContactController@pending')->name('admin.pending');

    Route::get('/filed/{id}','ContactController@shown')->name('');
    Route::get('/download/{file}','ContactController@download')->name('');

//status update
    Route::get('subscriber-status/{id}/{status}','ContactController@statusUpdate')->name('');

//student info
    Route::get('student','StudentController@index')->name('');
    Route::get('student/{id}','StudentController@show')->name('');
    Route::delete('student/{id}','StudentController@destroy')->name('');

});
Route::group(['as'=>'student.','prefix'=>'student','namespace'=>'Student','middleware'=>['auth','student']], function (){
    Route::get('dashboard','StudentController@index')->name('dashboard');
    Route::get('student-edit-pro','StudentController@editpro')->name('edit.profile');
    Route::get('/student-index','FileController@index')->name('student.index');
    Route::get('student-create','FileController@create')->name('');
    Route::get('/filed/{id}','FileController@show')->name('');
    Route::get('/download/{file}','FileController@download')->name('');
    Route::post('/student-store','FileController@storefile')->name('');
    Route::post('/student-edit-profile','StudentController@editprostore')->name('student.edit.profile');
    Route::get('/student-password-change','StudentController@passwordChange')->name('student.password.change');
    Route::post('/student-password-update','StudentController@passwordStore')->name('student.password.update');

    //Route::get('/student-send-file-create','StudentController@filecreate')->name('');
});

Route::get('/home', 'HomeController@index')->name('home');


//Admin layout data  compact
View::composer('*', function ($view) {
    $jernals = App\learningjernal::all();
    // $unreadedMessages = App\JernalSend::unreaded()->count();
    // $contactMessages = App\JernalSend::latest()->get();
    // $view->with('unreadedMessages', $unreadedMessages);
    // $view->with('contactMessages', $contactMessages);
    $view->with('jernals', $jernals);
});
