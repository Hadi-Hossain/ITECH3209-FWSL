<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateJernalSendsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('jernal_sends', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('user_id')->comment('user_id=student_id');
            $table->integer('jernal_id');
            $table->double('jernal_total');
            $table->integer('jernal_nob');
            $table->integer('status')->default(0)->comment('0=pending and 1=approved');
            $table->string('image')->nullable();
            $table->string('file')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('jernal_sends');
    }
}
