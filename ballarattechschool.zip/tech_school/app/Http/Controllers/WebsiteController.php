<?php

namespace App\Http\Controllers;

use App\learningjernal;
use Illuminate\Http\Request;

class WebsiteController extends Controller
{
    public function index(){
        $learnigs=learningjernal::latest()->take(6)->get();
        return view('website.index',compact('learnigs'));
    }
    public function element(){
        return view('website.elements');
    }
    public function article(){
        return view('website.article');
    }
    public function homecat(){
        return view('website.homecat');
    }
    public function homearticle(){
        return view('website.homearticle');
    }
    public function synthesis(){
        return view('website.synthesis');
    }
    public function single(){
        return view('website.single');
    }

    public function note(){
        $learnigs=learningjernal::latest()->take(6)->get();
        return view('website.note',compact('learnigs'));
    }
}
