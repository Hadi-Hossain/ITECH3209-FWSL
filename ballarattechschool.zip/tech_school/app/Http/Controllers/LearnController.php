<?php

namespace App\Http\Controllers;
use DB;
use Image;
use Session;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;

class LearnController extends Controller
{
    public function viplogin(){
        return view('website.student.login');
    }
    public function vipsinup(){
        return view('website.student.register');
    }
public function emailverify(){
    return view('website.student.verify');
}
    public function storesinup(Request $request){
      DB::transaction(function () use($request){
        $this->validate($request, [
    		'name' => 'required|string',
    		'email' => 'required|unique:users',
    		'phone' => 'required|string|unique:users',
    		'username' => 'required|string|unique:users',
    		'password' => 'required|string|min:6|confirmed',
            'address' => 'required',
            'image'   => 'required|mimes:jpeg,bmp,png',
        ]);
        $slug=uniqid(10);
        if($request->hasFile('image')){
            $image_tmp=$request->file('image');

            if($image_tmp->isValid()){
                $extention=$image_tmp->getClientOriginalExtension();
                $imageName= rand(111,99999).'.'.$extention;
                $imagePath='image/user/'.$imageName;
                Image::make($image_tmp)->resize(200,80)->save($imagePath);
            }else{
                $imageName="";
            }
          }
        $code=rand(0000,9999);
        $user = new User();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->phone;
        $user->username = $request->username;
        $user->address = $request->address;
        $user->image = $imageName;
        $user->code=$code;
        $user->slug=$slug;
        $user->role_id='2';
        $user->status='0';
        $user->password = Hash::make($request->password);
        $user->save();
        // $data=array(
        //     'code'=>$code,
        //     'email'=>$request->email,
        // );
        // Mail::send('website.emails.verify',$data,function($message)use($data){
        //             $message->from('careereschool1234@gmail.com','Balarat School');
        //             $message->to($data['email']);
        //             $message->subject('Plese verify your mail');
        // });
      });
      return redirect()->route('email.verify')->with('success','successfully sign');
    }

    public function verifystore(Request $request){
        $this->validate($request, [
    		'code' => 'required',
    		'email' => 'required',
        ]);
        $checkData= User::where('email',$request->email)->where('code',$request->code)->first();
        if($checkData){
            $checkData->status='1';
            $checkData->save();
            return redirect()->route('student.login');

        }else{
            return redirect()->back()->with('error','sorry');
        }

    }

    public function loginstore(Request $request)
    {
    	$this->validate($request, [
    		'email' => 'required',
    		'password' => 'required'
    	]);

    	$student = User::where('email', $request->email)->active()->first();
    	if($student){
    		if(Hash::check($request->password,$student->password)){
                $student->updated_at = Carbon::now()->toDateTimeString();
                $student->save();
                Session::put('role_id', $student->id);
	        	Session::flash('success', 'Login Success');
	        	return redirect()->route('student.dashboard');
	    	}else{
	    		Session::flash('error', 'Incorrect username or password.');
        		return redirect()->back();
	    	}
    	}else{
    		Session::flash('error', 'Incorrect username or password.');
        	return redirect()->back();
    	}

    }
}
