<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\JernalSend;
use Session;

class ContactController extends Controller
{
    public function index()
    {
        Session::put('page','dashboard');
    	$contactmessages = JernalSend::latest()->get();
    	return view('admin.contact.index', compact('contactmessages'));
    }
    public function show($id)
    {
    	$contactmessage = JernalSend::findOrFail($id);
    	if($contactmessage->status == 0){
    		$contactmessage->status = 1;
    		$contactmessage->save();
    	}
    	return view('admin.contact.show', compact('contactmessage'));
    }

    public function statusUpdate($id,$status){
        JernalSend::where('id',$id)->update(['mark'=>$status]);
       return redirect()->back()->with('success','updated the result');

    }
    // public function mark($mark)
    // {
    // 	$markgrade = JernalSend::findOrFail($mark);
    // 	if($markgrade->mark == 0){
    // 		$markgrade->mark = 3;
    // 		$markgrade->save();
    // 	}
    // 	return view('admin.contact.show', compact('markgrade'));
    // }
    public function destroy($id)
    {
    	$delete = JernalSend::findOrFail($id)->delete();
        if($delete){
            Session::flash('success', 'Message successfully deleted');
            return redirect()->back();
        }else{
            Session::flash('error', 'Message deleting failed');
            return redirect()->back();
        }
    }
    public function shown($id){
        $data=JernalSend::find($id);
        return view('admin.pdf.pdf',compact('data'));
    }
    public function download($file){
      return response()->download('image/pdf/'.$file);
  }
  public function pending(){
    $data=JernalSend::where('status','0')->get();
    return view('admin.pending.pendinglist',compact('data'));
  }
}
