<?php

namespace App\Http\Controllers\Admin;

use Session;
use App\User;
use App\Course;
use App\School;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SchoolController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        Session::put('page','dashboard');
        $schools=School::latest()->get();
        return view('admin.school.index',compact('schools'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $users=User::where('status',1)->latest()->get();
        $courses=Course::where('status',1)->latest()->get();
        return view('admin.school.create',compact('users','courses'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'name'=>'required|string|max:30',
            'user'=>'required',
            'course'=>'required',
        ]);
        $school=new School();
        $school->name=$request->name;
        $school->user_id=$request->user;
        $school->course_id=$request->course;
        $craete=$school->save();
        if($craete){
            Session::flash('success','Successfully Created!!');
            return redirect()->route('admin.school.index');
        }else {
            Session::flash('error','opps not Created!!');
            return redirect()->route('admin.school.index');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\School  $school
     * @return \Illuminate\Http\Response
     */
    public function show(School $school)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\School  $school
     * @return \Illuminate\Http\Response
     */
    public function edit(School $school)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\School  $school
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, School $school)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\School  $school
     * @return \Illuminate\Http\Response
     */
    public function destroy(School $school)
    {
        //
    }
}
