<?php

namespace App\Http\Controllers\Admin;
use Session;
use App\JernalSend;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AdminController extends Controller
{
    public function index(){
        Session::put('page','dashboard');
        $jernals=JernalSend::where('id','1')->count();
        $counts=User::where('id','1')->count();
        return view('admin.dashboard.index',compact('counts','jernals'));
    }
    public function login(){
        return view('admin.login.login');
    }
}
