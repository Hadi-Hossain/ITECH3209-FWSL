<?php

namespace App\Http\Controllers\Admin;

use App\Course;
use Session;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CourseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        Session::put('page','dashboard');
        $courses=Course::latest()->get();
        return view('admin.course.index',compact('courses'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.course.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'name'=>'required|string|max:20',
            'code'=>'required|integer|min:3|unique:courses',
            'text'=>'required|string',
            'assessment'=>'required',
        ]);
        $course=new Course();
        $course->name=$request->name;
        $course->code=$request->code;
        $course->text=$request->text;
        $course->assessment=$request->assessment;
        $create=$course->save();
        if($create){
            Session::flash('success','successfully craeted!!');
            return redirect()->route('admin.course.index');
        }else{
            Session::flash('error','opps Bad luck!!');
            return redirect()->route('admin.course.index');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function show(Course $course)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function edit(Course $course)
    {
        $course=Course::first();
        return view('admin.course.edit',compact('course'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Course $course)
    {
        $this->validate($request,[
            'name'=>'required|string|max:20',
            'code'=>'required|integer|min:3|unique:courses',
            'text'=>'required|string',
            'assessment'=>'required',
        ]);

        $course->name=$request->name;
        $course->code=$request->code;
        $course->text=$request->text;
        $course->assessment=$request->assessment;
        $update=$course->save();
        if($update)
        {
            Session::flash('success','Successfully Updated!!');
            return redirect()->route('admin.course.index');
        }else {
            Session::flash('error','opps not Updated!!');
            return redirect()->route('admin.course.index');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function destroy(Course $course)
    {
        $delete=$course->delete();
        if ($delete) {
            Session::flash('success','Successfully Deleted!!');
            return redirect()->route('admin.course.index');
        }else {
            Session::flash('error','opps not Deleted!!');
            return redirect()->route('admin.course.index');
        }
    }
}
