<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class learningjernal extends Model
{
    use SoftDeletes;
    public function user(){
        return $this->belongsTo('App\User');
    }

    public function course(){
        return $this->belongsTo('App\Course');
    }
    public function vipstudent(){
        return $this->belongsTo('App\VipStudent');
    }
    public function files(){
        return $this->hasMany('App\JernalSend');
    }
}
