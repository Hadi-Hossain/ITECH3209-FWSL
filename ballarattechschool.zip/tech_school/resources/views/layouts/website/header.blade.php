
     <div class="header-wrapper">
         <header>
          <div class="container">
            <div class="logo-container">
                <a href="index-2.html"  title="Tech School">
                    <img src="{{ asset('contents/website/assests/images/logo-1.png') }}" alt="Tech School">
                </a>
                <span class="tag-line">Ballarat Tech School</span>
            </div>         <!-- Start of Main Navigation -->
                <nav class="main-nav">
                        <div class="menu-top-menu-container">
                                <ul id="menu-top-menu" class="clearfix">
                                        <li><a href="{{ url('/') }}">Home</a></li>
                                        <li><a href="{{ url('/synthesis') }}">IT synthesis</a></li>
                                        <li class="current-menu-item"><a href="{{ url('/homearticle') }}">Health-Science</a></li>
                                        <li><a href="{{ url('/homecat') }}">IT synthesis</a></li>
                                        <li><a href="{{ url('/single') }}">FAQs</a></li>
                                        <li><a href="{{ url('/element') }}">Element</a></li>
                                        <li><a href="{{ url('/article') }}">Article</a>

                                        </li>
                                        <li><a href="{{ url('/note') }}">Note</a>
                                        </li>
                                        @if(@Auth::user()->id !=NUll)
                                        <li class="active-menu"><a href="">DashBoard</a>
                                            <ul class="sub-menu">
                                                <li style="color: red">My Profile</li>
                                                <li>My Jernal</li>
                                                <li>LOGOUT</li>
                                            </ul>
                                        </li>
                                        @else
                                        <li><a href="{{ url('/student/login') }}">Login</a></li>
                                        @endif
                                </ul>
                        </div>
                </nav>
            </div>
        </header>
    </div>


