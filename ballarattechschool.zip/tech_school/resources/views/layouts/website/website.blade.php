<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
        <head>
                <!-- META TAGS -->
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <meta name="csrf-token" content="{{csrf_token()}}">
                <title>::TECH SCHOOL::</title>
                <link rel="stylesheet" href="{{ asset('contents/website/assests/css/style.css') }}"/>
                <link rel="stylesheet" id="bootstrap-css-css"  href="{{ asset('contents/website/assests/css/bootstrap5152.css') }}" type="text/css" media="all" />
                <link rel="stylesheet" id="responsive-css-css"  href="{{ asset('contents/website/assests/css/responsive5152.css?ver=1.0') }}" type="text/css" media="all" />
                <link rel="stylesheet" id="main-css-css"  href="{{ asset('contents/website/assests/css/main5152.css?ver=1.0') }}" type="text/css" media="all" />
      <head>
          <body>

            @include('layouts.website.header')
            @yield('content')
            @include('layouts.website.footer')
            <script type="text/javascript" src="{{ asset('contents/website/assests/js/custom.js') }}"></script>
            <script type="text/javascript" src="{{ asset('contents/website/assests/js/jflickrfeed.js') }}"></script>
            <script type="text/javascript" src="{{ asset('contents/website/assests/js/jquery.form.js') }}"></script>
            <script type="text/javascript" src="{{ asset('contents/website/assests/js/jquery.easing.1.3.js') }}"></script>
            <script type="text/javascript" src="{{ asset('contents/website/assests/js/jquery.liveSearch.js') }}"></script>
            <script type="text/javascript" src="{{ asset('contents/website/assests/js/index.js') }}"></script>
          </body>
        </html>
