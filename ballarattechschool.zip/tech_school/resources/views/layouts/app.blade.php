{{-- <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    {{ config('app.name', 'Laravel') }}
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        @guest
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                            </li>
                            @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                                </li>
                            @endif
                        @else
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            @yield('content')
        </main>
    </div>
</body>
</html> --}}
<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
        <head>
                <!-- META TAGS -->
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <meta name="csrf-token" content="{{ csrf_token() }}">
                <title>@yield('title', 'Dashboard')</title>
                <link rel="stylesheet" href="{{ asset('contents/website/assests/css/style.css') }}"/>
                <link rel="stylesheet" id="bootstrap-css-css"  href="{{ asset('contents/website/assests/css/bootstrap5152.css') }}" type="text/css" media="all" />
                <link rel="stylesheet" id="responsive-css-css"  href="{{ asset('contents/website/assests/css/responsive5152.css?ver=1.0') }}" type="text/css" media="all" />
                <link rel="stylesheet" id="main-css-css"  href="{{ asset('contents/website/assests/css/main5152.css?ver=1.0') }}" type="text/css" media="all" />
                <!-- script -->

            <script type="text/javascript" src="{{ asset('contents/website/assests/js/custom.js') }}"></script>
            <script type="text/javascript" src="{{ asset('contents/website/assests/js/jflickrfeed.js') }}"></script>
            <script type="text/javascript" src="{{ asset('contents/website/assests/js/jquery.form.js') }}"></script>
            <script type="text/javascript" src="{{ asset('contents/website/assests/js/jquery.easing.1.3.js') }}"></script>
            <script type="text/javascript" src="{{ asset('contents/website/assests/js/jquery.liveSearch.js') }}"></script>
            <script type="text/javascript" src="{{ asset('contents/website/assests/js/index.js') }}"></script>

        </head>
        <body>
             <div class="header-wrapper">
                 <header>
                  <div class="container">
                    <div class="logo-container">
                        <a href="index-2.html"  title="Tech School">
                            <img src="{{ asset('contents/website/assests/images/logo-1.png') }}" alt="Tech School">
                        </a>
                        <span class="tag-line">Ballarat Tech School</span>
                    </div>         <!-- Start of Main Navigation -->
                        <nav class="main-nav">
                                <div class="menu-top-menu-container">
                                        <ul id="menu-top-menu" class="clearfix">
                                                <li><a href="index-2.html">Home</a></li>
                                                <li><a href="home-categories-description.html">IT synthesis</a></li>
                                                <li class="current-menu-item"><a href="home-categories-articles.html">Health-Science</a></li>
                                                <li><a href="articles-list.html">Food and Fibre</a></li>
                                                <li><a href="faq.html">FAQs</a></li>
                                                <li><a href="#">New-engry</a>
                                                <ul class="sub-menu">
                                                </ul>
                                                </li>
                                                <li><a href="Note.html">Note</a>

                                                </li>
                                                <li><a href="Login.html">Login</a></li>
                                        </ul>
                                </div>
                        </nav>
                    </div>
                </header>
            </div>
                <!-- End of Header -->
               @yield('content')
                <!-- Start of Footer -->
            <footer id="footer-wrapper">
                    <div id="footer" class="container">
                            <div class="row">

                                    <div class="span3">
                                            <section class="widget">
                                                    <h3 class="title">Spare footer </h3>
                                                    <div class="textwidget">
                                                            <p> </p>
                                                            <p> </p>
                                                    </div>
                                            </section>
                                    </div>

                                    <div class="span3">
                                            <section class="widget"><h3 class="title">Categories</h3>
                                                    <ul>
                                                            <li><a href="#" title="Lorem ipsum dolor sit amet,">IT synthesis</a> </li>
                                                            <li><a href="#" title="Lorem ipsum dolor sit amet,">Health-Science</a></li>
                                                            <li><a href="#" title="Lorem ipsum dolor sit amet,">Food and Fibre</a></li>
                                                            <li><a href="#" title="Lorem ipsum dolor sit amet, ">New-engry</a></li>
                                                            <li><a href="#" title="Lorem ipsum dolor sit amet,">Advanced-manufacturing</a></li>
                                                            <li><a href="#" title="Lorem ipsum dolor sit amet,">STEAM</a></li>
                                                            <li><a href="#" title="Lorem ipsum dolor sit amet, ">About</a></li>
                                                    </ul>
                                            </section>
                                    </div>

                                    <div class="span3">
                                            <section class="widget">
                                                    <h3 class="title">Latest Tweets</h3>
                                                    <div id="twitter_update_list">
                                                            <ul>
                                                                    <li>No Tweets loaded !</li>
                                                            </ul>
                                                    </div>

                                            </section>
                                    </div>

                                    <div class="span3">
                                            <section class="widget">
                                                    <h3 class="title">Flickr Photos</h3>
                                                    <div class="flickr-photos" id="basicuse">
                                                    </div>
                                            </section>
                                    </div>

                            </div>
                    </div>
                    <!-- Footer Bottom -->
                    <div id="footer-bottom-wrapper">
                            <div id="footer-bottom" class="container">
                                    <div class="row">
                                            <div class="span6">
                                        </div>
                                            <div class="span6">
                                                    <!-- Social Navigation -->
                                                    <ul class="social-nav clearfix">
                                                            <li class="linkedin"><a target="_blank" href="#"></a></li>
                                                            <li class="stumble"><a target="_blank" href="#"></a></li>
                                                            <li class="google"><a target="_blank" href="#"></a></li>
                                                            <li class="deviantart"><a target="_blank" href="#"></a></li>
                                                            <li class="flickr"><a target="_blank" href="#"></a></li>
                                                            <li class="skype"><a target="_blank" href="skype:#?call"></a></li>
                                                            <li class="rss"><a target="_blank" href="#"></a></li>
                                                            <li class="twitter"><a target="_blank" href="#"></a></li>
                                                            <li class="facebook"><a target="_blank" href="#"></a></li>
                                                    </ul>
                                            </div>
                                    </div>
                            </div>
                    </div>
                    <!-- End of Footer Bottom -->

            </footer>

        </body>


</html>
<!--zhenting-->
