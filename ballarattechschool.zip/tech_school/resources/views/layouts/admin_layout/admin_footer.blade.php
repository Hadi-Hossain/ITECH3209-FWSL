<footer class="footer text-center">
    &copy All Rights Reserved by RedLine. Developed by
    <a href="#">Creative Shaper</a>.
</footer>
