@extends('layouts.website.website')
@section('content')
     <!-- Start of Search Wrapper -->
     <div class="search-area-wrapper">
        <div class="search-area container">
                <h3 class="search-header">Have a Question?</h3>
                <p class="search-tag-line">If you have any question you can ask below or enter what you are looking for!</p>

                <form id="search-form" class="search-form clearfix" method="get" action="#" autocomplete="off">
                        <input class="search-term required" type="text" id="s" name="s" placeholder="Type your search terms here" title="* Please enter a search term!" />
                        <input class="search-btn" type="submit" value="Search" />
                        <div id="search-error-container"></div>
                </form>
        </div>
</div>
<div class="page-container">
        <div class="container">
                <div class="row">
                        <div class="span8 main-listing">
                                <article class="format-standard type-post hentry clearfix">
                                        <header class="clearfix">
                                                <h3 class="post-title">
                                                        <a href="single.html">Website building foundation and advanced training</a>
                                                </h3>
                                                <div class="post-meta clearfix">
                                                        <span class="date">25 Feb, 2020</span>
                                                        <span class="category"><a href="#" title="View all posts in IT synthesis">IT synthesis</a></span>
                                                        <span class="comments"><a href="#" title="Comment on Integrating WordPress with Your Website">3 Comments</a></span>
                                                        <span class="like-count">77</span>
                                                </div>
                                        </header>

                                        <p>Place a link to an article  <a class="readmore-link" >Read more</a></p>

                                </article>

                                <article class="format-standard type-post hentry clearfix">

                                        <header class="clearfix">

                                                <h3 class="post-title">
                                                        <a href="single.html">Using Javascript</a>
                                                </h3>

                                                <div class="post-meta clearfix">
                                                        <span class="date">25 Feb, 2017</span>
                                                        <span class="category"><a href="#" title="View all posts in IT synthesis">IT synthesis</a></span>
                                                        <span class="comments"><a href="#" title="Comment on Using Javascript">0 Comments</a></span>
                                                        <span class="like-count">18</span>
                                                </div><!-- end of post meta -->

                                        </header>
                                        <p>Place a link to an article <a class="readmore-link" >Read more</a></p>

                                </article>
                                <article class=" type-post format-image hentry clearfix">

                                        <header class="clearfix">

                                                <h3 class="post-title">
                                                        <a href="single.html">Using Images</a>
                                                </h3>

                                                <div class="post-meta clearfix">
                                                        <span class="date">25 Feb, 2013</span>
                                                        <span class="category"><a href="#" title="View all posts in IT synthesis">IT synthesis</a></span>
                                                        <span class="comments"><a href="#" title="Comment on Using Images">0 Comments</a></span>
                                                        <span class="like-count">7</span>
                                                </div><!-- end of post meta -->

                                        </header>

                                        <a href="#" title="Using Images"><img width="770" height="501" src="{{ asset('contents/website/assests/images/Icons/IT_WiFi-Cloud.png') }}" class="attachment-std-thumbnail wp-post-image" alt="Living room"></a>

                                        <p>Place a link to an article <a class="readmore-link" >Read more</a></p>

                                </article>

                                <article class="type-post  format-video hentry clearfix">

                                        <header class="clearfix">

                                                <h3 class="post-title">
                                                        <a href="single.html">Using Video</a>
                                                </h3>

                                                <div class="post-meta clearfix">
                                                        <span class="date">16 Feb, 2019</span>
                                                        <span class="category"><a href="#" title="View all posts in IT synthesis">IT synthesis</a></span>

                                                        <span class="comments"><a href="#" title="Comment on Using Video">0 Comments</a></span>

                                                        <span class="like-count">7</span>
                                                </div><!-- end of post meta -->

                                        </header>
                                        <div class="post-video">
                                                <div class="video-wrapper">
                                                        <iframe  width="500" height="281" frameborder="0" webkitallowfullscreen="" mozallowfullscreen="" allowfullscreen="">video</iframe><!--put a link here-->
                                                </div>
                                        </div>

                                        <p>Put a video link in here<a class="readmore-link" >Read more</a></p>

                                </article>

                                <article class=" type-post  format-standard hentry clearfix">

                                        <header class="clearfix">

                                                <h3 class="post-title">
                                                        <a href="single.html">WordPress Site Maintenance</a>
                                                </h3>

                                                <div class="post-meta clearfix">
                                                        <span class="date">18 Jun, 2017</span>
                                                        <span class="category"><a href="#" title="View all posts in IT synthesis">IT synthesis</a></span>

                                                        <span class="comments"><a href="#" title="Comment on WordPress Site Maintenance">0 Comments</a></span>

                                                        <span class="like-count">45</span>
                                                </div><!-- end of post meta -->

                                        </header>

                                        <p>Put a video link in here <a class="readmore-link" >Read more</a></p>

                                </article>

                                <div id="pagination">
                                        <a href="#" class="btn active">1</a>
                                        <a href="#" class="btn">2</a>
                                        <a href="#" class="btn">3</a>
                                        <a href="#" class="btn">Next »</a>
                                        <a href="#" class="btn">Last »</a>
                                </div>

                        </div>
                        <!-- end of page content -->


                        <!-- start of sidebar -->
                        <aside class="span4 page-sidebar">

                                <section class="widget">
                                        <div class="support-widget">
                                                <h3 class="title">Support</h3>
                                                <p class="intro">Need more support? If you did not found an answer, contact us for further help.</p>
                                        </div>
                                </section>


                                <section class="widget">
                                        <h3 class="title">Featured Articles</h3>
                                        <ul class="articles">
                                                <li class="article-entry standard">
                                                                <h4><a href="single.html">Website building foundation and advanced training </a></h4>
                                                                <span class="article-meta">25 Feb, 2020 in <a href="single.html" title="View all posts in IT synthesis">IT synthesis</a></span>
                                                                <span class="like-count">77</span>
                                                        </li>
                                                        <li class="article-entry standard">
                                                                <h4><a href="single.html">PHP advanced training </a></h4>
                                                                <span class="article-meta">24 Feb, 2020 in <a href="single.html" title="View all posts in IT synthesis">IT synthesis</a></span>
                                                                <span class="like-count">80</span>
                                                        </li>
                                                        <li class="article-entry video">
                                                                <h4><a href="single.html">Influenza virus differentiation  </a></h4>
                                                                <span class="article-meta">10 Dec, 2019 in <a href="single.html" title="View all posts in Health-Science">Health-Science</a></span>
                                                                <span class="like-count">76</span>
                                                        </li>
                                                        <li class="article-entry image">
                                                                <h4><a href="single.html">Fundamentals of Engineering </a></h4>
                                                                <span class="article-meta">10 Jul, 2017 in <a href="single.html" title="View all posts in New-engry">New-engry</a></span>
                                                                <span class="like-count">120</span>
                                                        </li>
                                    </ul>

                                </section>



                                <section class="widget"><h3 class="title">Categories</h3>
                                        <ul>
                                                <li><a href="#" title="Lorem ipsum dolor sit amet,">IT synthesis</a> </li>
                                                <li><a href="#" title="Lorem ipsum dolor sit amet,">Health-Science</a></li>
                                                <li><a href="#" title="Lorem ipsum dolor sit amet,">Food and Fibre</a></li>
                                                <li><a href="#" title="Lorem ipsum dolor sit amet, ">New-engry</a></li>
                                                <li><a href="#" title="Lorem ipsum dolor sit amet,">Advanced-manufacturing</a></li>
                                                <li><a href="#" title="Lorem ipsum dolor sit amet,">STEAM</a></li>
                                                <li><a href="#" title="Lorem ipsum dolor sit amet, ">About</a></li>
                                    </ul>
                                </section>

                                <section class="widget">
                                        <h3 class="title">Recent Comments</h3>
                                        <ul id="recentcomments">
                                                <li class="recentcomments"><a href="#" rel="external nofollow" class="url">xxxxx xx</a> on <a href="#">Website building foundation and advanced training</a></li>
                                                <li class="recentcomments">xxxxxxxx <a href="#">PHP advanced training </a></li>
                                                <li class="recentcomments"><a href="#" rel="external nofollow" class="url">xxxxx</a> on <a href="#">Influenza virus differentiation</a></li>
                                                <li class="recentcomments"><a href="#" rel="external nofollow" class="url">xxxxxx</a> on <a href="#">Installing WordPress</a></li>
                                        </ul>
                                </section>

                        </aside>
                        <!-- end of sidebar -->
                </div>
        </div>
</div>
<!-- End of Page Container -->

@endsection
