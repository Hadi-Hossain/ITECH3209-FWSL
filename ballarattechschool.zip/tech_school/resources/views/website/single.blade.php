@extends('layouts.website.website')
@section('content')
                <!-- Start of Search Wrapper -->
                <div class="search-area-wrapper">
                        <div class="search-area container">
                                <h3 class="search-header">Have a Question?</h3>
                                <p class="search-tag-line">If you have any question you can ask below or enter what you are looking for!</p>

                                <form id="search-form" class="search-form clearfix" method="get" action="#" autocomplete="off">
                                        <input class="search-term required" type="text" id="s" name="s" placeholder="Type your search terms here" title="* Please enter a search term!" />
                                        <input class="search-btn" type="submit" value="Search" />
                                        <div id="search-error-container"></div>
                                </form>
                        </div>
                </div>
                <!-- End of Search Wrapper -->

                <!-- Start of Page Container -->
                <div class="page-container">
                        <div class="container">
                                <div class="row">

                                        <!-- start of page content -->
                                        <div class="span8 page-content">

                                                <ul class="breadcrumb">
                                                        <li><a href="#">Tech School</a><span class="divider">/</span></li>
                                                        <li><a href="#" title="View all posts in IT synthesis">IT synthesis</a> <span class="divider">/</span></li>
                                                        <li class="active">Website building foundation and advanced training </li>
                                                </ul>

                                                <article class=" type-post format-standard hentry clearfix">

                                                        <h1 class="post-title"><a href="#">Website building foundation and advanced training </a></h1>

                                                        <div class="post-meta clearfix">
                                                                <span class="date">25 Feb, 2020</span>
                                                                <span class="category"><a href="#" title="View all posts in IT synthesis">IT synthesis</a></span>
                                                                <span class="comments"><a href="#" title="Comment on Integrating WordPress with Your Website">3 Comments</a></span>
                                                                <span class="like-count">77</span>
                                                        </div><!-- end of post meta -->

                                                        <p>Article content </p>

                                                        <p>Article content </p>

                                                        <p>Article content </p>

                                                        <h3>Article segmentation </h3>

                                                        <p>Article content </p>

                                                        <ul>
                                                                <li>Article content </li>
                                                                <li>Article content </li>
                                                                <li>Article content </li>
                                                                <li>Article content </li>
                                                        </ul>

                                                        <p>Article content </p>

                                                        <h3>Article segmentation</h3>

                                                        <p>Article content </p>

                                                        <p>Article content</p>

                                                        <p>Article content</p>

                                                        <blockquote><p>Article content</p></blockquote>

                                                        <h3>Article segmentation</h3>

                                                        <p>Article content</p>

                                                        <p>Article content</p>

                                                        <p>Article content</p>

                                                        <h3>Article segmentation</h3>

                                                        <p>Article content</p>

                                                        <p>Article content</p>

                                                        <ol>
                                                                <li>Article content</li>
                                                                <li>Article content</li>
                                                                <li>Article content</li>
                                                                <li>Article content</li>
                                                        </ol>

                                                        <p>Article content</p>

                                                </article>

                                                <div class="like-btn">

                                                        <form id="like-it-form" action="#" method="post">
                                                                <span class="like-it ">66</span>
                                                                <input type="hidden" name="post_id" value="99">
                                                                <input type="hidden" name="action" value="like_it">
                                                        </form>

                                                        <span class="tags">
                                                                <strong>Tags:&nbsp;&nbsp;</strong><a href="#" rel="tag">basic</a>, <a href="#" rel="tag">setting</a>, <a href="http://knowledgebase.inspirythemes.com/tag/website/" rel="tag">website</a>
                                                        </span>

                                                </div>

                                                <section id="comments">

                                                        <h3 id="comments-title">(3) Comments</h3>

                                                        <ol class="commentlist">

                                                                <li class="comment even thread-even depth-1" id="li-comment-2">
                                                                        <article id="comment-2">

                                                                                <a href="#">
                                                                                        <img alt="" src="http://0.gravatar.com/avatar/2df5eab0988aa5ff219476b1d27df755?s=60&amp;d=http%3A%2F%2F0.gravatar.com%2Favatar%2Fad516503a11cd5ca435acc9bb6523536%3Fs%3D60&amp;r=G" class="avatar avatar-60 photo" height="60" width="60">
                                                                                </a>

                                                                                <div class="comment-meta">

                                                                                        <h5 class="author">
                                                                                                <cite class="fn">
                                                                                                        <a href="#" rel="external nofollow" class="url">xxxxx</a>
                                                                                                </cite>
                                                                                                - <a class="comment-reply-link" href="#">Reply</a>
                                                                                        </h5>

                                                                                        <p class="date">
                                                                                                <a href="#">
                                                                                                        <time datetime="2020-02-26T13:18:47+00:00">February 26, 2020 at 1:18 pm</time>
                                                                                                </a>
                                                                                        </p>

                                                                                </div><!-- end .comment-meta -->

                                                                                <div class="comment-body">
                                                                                        <p>Article content</p>
                                                                                        <p>Article content</p>
                                                                                </div><!-- end of comment-body -->

                                                                        </article><!-- end of comment -->

                                                                        <ul class="children">

                                                                                <li class="comment byuser comment-author-saqib-sarwar bypostauthor odd alt depth-2" id="li-comment-3">
                                                                                        <article id="comment-3">

                                                                                                <a href="#">
                                                                                                        <img alt="" src="http://0.gravatar.com/avatar/2df5eab0988aa5ff219476b1d27df755?s=60&amp;d=http%3A%2F%2F0.gravatar.com%2Favatar%2Fad516503a11cd5ca435acc9bb6523536%3Fs%3D60&amp;r=G" class="avatar avatar-60 photo" height="60" width="60">
                                                                                                </a>

                                                                                                <div class="comment-meta">

                                                                                                        <h5 class="author">
                                                                                                                <cite class="fn">saqib sarwar</cite>
                                                                                                                - <a class="comment-reply-link" href="#">Reply</a>
                                                                                                        </h5>

                                                                                                        <p class="date">
                                                                                                                <a href="#">
                                                                                                                        <time datetime="2020-02-26T13:20:14+00:00">February 26, 2020 at 1:20 pm</time>
                                                                                                                </a>
                                                                                                        </p>

                                                                                                </div><!-- end .comment-meta -->

                                                                                                <div class="comment-body">
                                                                                                        <p>Article content</p>
                                                                                                </div><!-- end of comment-body -->

                                                                                        </article><!-- end of comment -->

                                                                                </li>
                                                                        </ul>
                                                                </li>

                                                                <li class="comment even thread-odd thread-alt depth-1" id="li-comment-4">
                                                                        <article id="comment-4">

                                                                                <a href="#">
                                                                                        <img alt="" src="http://0.gravatar.com/avatar/2df5eab0988aa5ff219476b1d27df755?s=60&amp;d=http%3A%2F%2F0.gravatar.com%2Favatar%2Fad516503a11cd5ca435acc9bb6523536%3Fs%3D60&amp;r=G" class="avatar avatar-60 photo" height="60" width="60">
                                                                                </a>

                                                                                <div class="comment-meta">

                                                                                        <h5 class="author">
                                                                                                <cite class="fn"><a href="#" rel="external nofollow" class="url">xxxxx</a></cite>
                                                                                                - <a class="comment-reply-link" href="#">Reply</a>
                                                                                        </h5>

                                                                                        <p class="date">
                                                                                                <a >
                                                                                                        <time datetime="2020-02-26T13:27:04+00:00">February 26, 2020 at 1:27 pm</time>
                                                                                                </a>
                                                                                        </p>

                                                                                </div><!-- end .comment-meta -->

                                                                                <div class="comment-body">
                                                                                        <p>Article content</p>
                                                                                        <p>Article content</p>
                                                                                </div><!-- end of comment-body -->

                                                                        </article><!-- end of comment -->
                                                                </li>
                                                        </ol>

                                                        <div id="respond">

                                                                <h3>Leave a Reply</h3>

                                                                <div class="cancel-comment-reply">
                                                                        <a rel="nofollow" id="cancel-comment-reply-link" href="#" style="display:none;">Click here to cancel reply.</a>
                                                                </div>


                                                                <form action="#" method="post" id="commentform">


                                                                        <p class="comment-notes">Your email address will not be published. Required fields are marked <span class="required">*</span></p>

                                                                        <div>
                                                                                <label for="author">Name *</label>
                                                                                <input class="span4" type="text" name="author" id="author" value="" size="22">
                                                                        </div>

                                                                        <div>
                                                                                <label for="email">Email *</label>
                                                                                <input class="span4" type="text" name="email" id="email" value="" size="22" >
                                                                        </div>

                                                                        <div>
                                                                                <label for="url">Website</label>
                                                                                <input class="span4" type="text" name="url" id="url" value="" size="22" >
                                                                        </div>


                                                                        <div>
                                                                                <label for="comment">Comment</label>
                                                                                <textarea class="span8" name="comment" id="comment" cols="58" rows="10"></textarea>
                                                                        </div>

                                                                        <p class="allowed-tags"></p>

                                                                        <div>
                                                                                <input class="btn" name="submit" type="submit" id="submit"  value="Submit Comment">
                                                                        </div>

                                                                </form>

                                                        </div>

                                                </section><!-- end of comments -->

                                        </div>
                                        <!-- end of page content -->


                                        <!-- start of sidebar -->
                                        <aside class="span4 page-sidebar">

                                                <section class="widget">
                                                        <div class="support-widget">
                                                                <h3 class="title">Support</h3>
                                                                <p class="intro">Need more support? If you did not found an answer, contact us for further help.</p>
                                                        </div>
                                                </section>


                                                <section class="widget">
                                                        <h3 class="title">Featured Articles</h3>
                                                        <ul class="articles">
                                                                <li class="article-entry standard">
                                                                                <h4><a href="single.html">Website building foundation and advanced training </a></h4>
                                                                                <span class="article-meta">25 Feb, 2020 in <a href="single.html" title="View all posts in IT synthesis">IT synthesis</a></span>
                                                                                <span class="like-count">77</span>
                                                                        </li>
                                                                        <li class="article-entry standard">
                                                                                <h4><a href="single.html">PHP advanced training </a></h4>
                                                                                <span class="article-meta">24 Feb, 2020 in <a href="single.html" title="View all posts in IT synthesis">IT synthesis</a></span>
                                                                                <span class="like-count">80</span>
                                                                        </li>
                                                                        <li class="article-entry video">
                                                                                <h4><a href="single.html">Influenza virus differentiation  </a></h4>
                                                                                <span class="article-meta">10 Dec, 2019 in <a href="single.html" title="View all posts in Health-Science">Health-Science</a></span>
                                                                                <span class="like-count">76</span>
                                                                        </li>
                                                                        <li class="article-entry image">
                                                                                <h4><a href="single.html">Fundamentals of Engineering </a></h4>
                                                                                <span class="article-meta">10 Jul, 2017 in <a href="single.html" title="View all posts in New-engry">New-engry</a></span>
                                                                                <span class="like-count">120</span>
                                                                        </li>
                                                                        <li class="article-entry standard">
                                                                                <h4><a href="single.html">Food health classification </a></h4>
                                                                                <span class="article-meta">17 Jun, 2018 in <a href="single.html" title="View all posts in Food and Fibre">Food and Fibre</a></span>
                                                                                <span class="like-count">68</span>
                                                                        </li>
                                                                        <li class="article-entry standard">
                                                                                <h4><a href="single.html">Advanced mechanical dynamics </a></h4>
                                                                                <span class="article-meta">21 Feb, 2013 in <a href="single.html" title="View all posts in New-engry">New-engry</a></span>
                                                                                <span class="like-count">75</span>
                                                                        </li>
                                                        </ul>
                                                </section>



                                                <section class="widget"><h3 class="title">Categories</h3>
                                                        <ul>
                                                                <li><a href="#" title="Lorem ipsum dolor sit amet,">IT synthesis</a> </li>
                                                                <li><a href="#" title="Lorem ipsum dolor sit amet,">Health-Science</a></li>
                                                                <li><a href="#" title="Lorem ipsum dolor sit amet,">Food and Fibre</a></li>
                                                                <li><a href="#" title="Lorem ipsum dolor sit amet, ">New-engry</a></li>
                                                                <li><a href="#" title="Lorem ipsum dolor sit amet,">Advanced-manufacturing</a></li>
                                                                <li><a href="#" title="Lorem ipsum dolor sit amet,">STEAM</a></li>
                                                                <li><a href="#" title="Lorem ipsum dolor sit amet, ">About</a></li>
                                                        </ul>
                                                </section>

                                                <section class="widget">
                                                        <h3 class="title">Recent Comments</h3>
                                                        <ul id="recentcomments">
                                                                <li class="recentcomments"><a href="#" rel="external nofollow" class="url">xxxxx</a> on <a href="#">Website building foundation and advanced training </a></li>
                                                                <li class="recentcomments">xxxxx <a href="#">Website building foundation and advanced training </a></li>
                                                                <li class="recentcomments"><a href="#" rel="external nofollow" class="url">xxxxxx</a> on <a href="#">Website building foundation and advanced training </a></li>
                                                                <li class="recentcomments"><a href="#" rel="external nofollow" class="url">xxxxx</a> on <a href="#">Website building foundation and advanced training </a></li>
                                                        </ul>
                                                </section>

                                        </aside>
                                        <!-- end of sidebar -->
                                </div>
                        </div>
                </div>
                <!-- End of Page Container -->
@endsection
