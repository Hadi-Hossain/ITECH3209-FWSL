@extends('layouts.website.website')
@section('content')
     <!-- Start of Search Wrapper -->
     <div class="search-area-wrapper">
        <div class="search-area container">
                <h3 class="search-header">Have a Question?</h3>
                <p class="search-tag-line">If you have any question you can ask below or enter what you are looking for!</p>

                <form id="search-form" class="search-form clearfix" method="get" action="#" autocomplete="off">
                        <input class="search-term required" type="text" id="s" name="s" placeholder="Type your search terms here" title="* Please enter a search term!" />
                        <input class="search-btn" type="submit" value="Search" />
                        <div id="search-error-container"></div>
                </form>
        </div>
</div>
<div class="page-container">
        <div class="container">
                <div class="row">
                        <!-- start of page content -->
                        <div class="span8 page-content">
                                <div class="row home-category-list-area">
                                        <div class="span8">
                                                <h2>Note</h2>
                                        </div>
                                </div>
                                <div class="row-fluid top-cats">
                                       @foreach ($learnigs as $learnig)
                                       <section class="span4">
                                        @if(@Auth::user()->id !=NULL)
                                        <h4><a href="{{ url('student/dashboard') }}">{{str_limit( $learnig->jernal_name,'10') }}</a></h4>
                                        @else
                                        <h4 class="category"><a href="{{ url('/student/login') }}">{{str_limit( $learnig->jernal_name,'10') }}</a></h4>
                                        @endif
                                        <div class="category-description">
                                        <p>{{ $learnig->jernal_content }}</p>
                                        <h5>Date:{{$learnig->created_at =date('Y-m-d')}}</br>{{ $learnig->created_at->diffForHumans() }}</h5>
                                        <h6>Created By: <strong>{{ $learnig->user->name }}</strong></h6>
                                        </div>
                                       </section>
                                       @endforeach
                                </div>
                        </div>
                        <aside class="span4 page-sidebar">

                                <section class="widget">
                                        <div class="support-widget">
                                                <h3 class="title">Support</h3>
                                                <p class="intro">Need more support? If you did not found an answer, contact us for further help.</p>
                                        </div>
                                </section>

                                <section class="widget">
                                        <div class="quick-links-widget">
                                                <h3 class="title">Subject</h3>
                                                <ul id="menu-quick-links" class="menu clearfix">
                                                       <li><a href="index-2.html">IT Synthesis</a></li>
                                                        <li><a href="articles-list.html">Health Science</a></li>
                                                        <li><a href="contact.html">Food and Fibre</a></li>
                                                </ul>
                                        </div>
                                </section>

                                <section class="widget">
                                        <h3 class="title">Tags</h3>
                                        <div class="tagcloud">
                                                <a href="#" class="btn btn-mini">basic</a>
                                                <a href="#" class="btn btn-mini">beginner</a>
                                                <a href="#" class="btn btn-mini">blogging</a>
                                                <a href="#" class="btn btn-mini">colour</a>
                                                <a href="#" class="btn btn-mini">css</a>
                                                <a href="#" class="btn btn-mini">date</a>
                                                <a href="#" class="btn btn-mini">design</a>
                                                <a href="#" class="btn btn-mini">files</a>
                                                <a href="#" class="btn btn-mini">format</a>
                                                <a href="#" class="btn btn-mini">header</a>
                                                <a href="#" class="btn btn-mini">images</a>
                                                <a href="#" class="btn btn-mini">plugins</a>
                                                <a href="#" class="btn btn-mini">setting</a>
                                                <a href="#" class="btn btn-mini">templates</a>
                                                <a href="#" class="btn btn-mini">theme</a>
                                                <a href="#" class="btn btn-mini">time</a>
                                                <a href="#" class="btn btn-mini">videos</a>
                                                <a href="#" class="btn btn-mini">website</a>
                                                <a href="#" class="btn btn-mini">wordpress</a>
                                        </div>
                                </section>

                        </aside>
                        <!-- end of sidebar -->
                </div>
        </div>
</div>
@endsection
