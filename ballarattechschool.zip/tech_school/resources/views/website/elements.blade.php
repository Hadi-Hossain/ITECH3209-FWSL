
@extends('layouts.website.website')
@section('content')
                <!-- Start of Search Wrapper -->
    <div class="search-area-wrapper">
            <div class="search-area container">
                    <h3 class="search-header">Have a Question?</h3>
                    <p class="search-tag-line">If you have any question you can ask below or enter what you are looking for!</p>

                    <form id="search-form" class="search-form clearfix" method="get" action="#" autocomplete="off">
                            <input class="search-term required" type="text" id="s" name="s" placeholder="Type your search terms here" title="* Please enter a search term!" />
                            <input class="search-btn" type="submit" value="Search" />
                            <div id="search-error-container"></div>
                    </form>
            </div>
    </div>
    <div class="page-container">
            <div class="container">
                    <div class="row">

                            <!-- start of page content -->
                            <div class="span12 page-content">

                                    <article class="type-page hentry clearfix">

                                            <h1 class="post-title"><a href="#">Elements</a></h1>

                                            <hr>

                                            <h3>Tabs</h3>

                                            <ul class="tabs-nav">
                                                    <li class="active" style=""><a href="#">First Tab</a></li>
                                                    <li><a href="#">Second Tab</a></li>
                                                    <li><a href="#">Third Tab</a></li>
                                            </ul>

                                            <div class="tabs-container">
                                                    <div class="tab-content"></div>
                                                    <div class="tab-content">Second </div>
                                                    <div class="tab-content">Third </div>
                                            </div>

                                            <h3>Accordion</h3>
                                            <dl class="accordion clearfix">
                                                    <dt><span></span>First Accordion Item</dt>
                                                    <dd>Although starting a prototype on a is sometimes easi problem-solve. When you need to ideate website prototype on a is sometimes easier, it’s not the best When you or to storyboard context Although starting a prototype on a is sometimes easi problem- solve. When you need to ideate website …</dd>

                                                    <dt><span></span>Second Accordion Item</dt>
                                                    <dd>Although starting a prototype on a is sometimes easi problem-solve. When you need to ideate website prototype on a is sometimes easier, it’s not the best When you or to storyboard context Although starting a prototype on a is sometimes easi problem- solve. When you need to ideate website …</dd>

                                                    <dt><span></span>Third Accordion Item</dt>
                                                    <dd>Although starting a prototype on a is sometimes easi problem-solve. When you need to ideate website prototype on a is sometimes easier, it’s not the best When you or to storyboard context Although starting a prototype on a is sometimes easi problem- solve. When you need to ideate website …</dd>
                                            </dl>

                                            <h3>Toggles</h3>
                                            <dl class="toggle clearfix">
                                                    <dt><span></span>First Accordion Item</dt>
                                                    <dd>Although starting a prototype on a is sometimes easi problem-solve. When you need to ideate website prototype on a is sometimes easier, it’s not the best When you or to storyboard context Although starting a prototype on a is sometimes easi problem- solve. When you need to ideate website …</dd>

                                                    <dt><span></span>Second Accordion Item</dt>
                                                    <dd>Although starting a prototype on a is sometimes easi problem-solve. When you need to ideate website prototype on a is sometimes easier, it’s not the best When you or to storyboard context Although starting a prototype on a is sometimes easi problem- solve. When you need to ideate website …</dd>

                                                    <dt><span></span>Third Accordion Item</dt>
                                                    <dd>Although starting a prototype on a is sometimes easi problem-solve. When you need to ideate website prototype on a is sometimes easier, it’s not the best When you or to storyboard context Although starting a prototype on a is sometimes easi problem- solve. When you need to ideate website …</dd>
                                            </dl>

                                            <h3>Blockquote</h3>
                                            <blockquote>
                                                    <p>Lorem </p>
                                            </blockquote>

                                            <h3>Messages</h3>

                                            <p class="error">Lorem </p>

                                            <p class="success">Lorem </p>

                                            <p class="info">Lorem </p>

                                            <p class="notice">Lorem </p>
                                    </article>
                            </div>
                    </div>
            </div>
    </div>     <!-- End of Page Container -->
@endsection
