<h2 style="color: red;font-weight=600;">You Information</h2>
<div style="padding-left: 50px;">
 <p>Email:{{ $email }}</p>
 <p> Verification Code:{{ $code }}</p>
</div>
<h5 style="color:orange;">You should confirm this code to login!!</h5>
