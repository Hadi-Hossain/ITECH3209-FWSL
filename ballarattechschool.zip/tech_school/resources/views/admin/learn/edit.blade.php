@extends('layouts.admin_layout.admin_layout')
@section('title', $learningjernal->jernal_name)

@section('content')
    <!-- Bread crumb and right sidebar toggle -->

    @component('admin.dashboard.breadcumb')
    <li class="breadcrumb-item"><a href="{{url('admin/learningjernal')}}">Jearnal</a></li>
    <li class="breadcrumb-item active" aria-current="page">edit</li>
    @endcomponent

    <!-- End Bread crumb and right sidebar toggle -->
    <div class="page-content container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
						<div class="pull-left">
							<h6 class="card-title mt-1">Update Jearnal</h6>
						</div>
						<div class="pull-right">
                            <a href="{{url('/admin/learningjernal')}}" class="btn btn-outline-info btn-sm"><i class="mdi mdi-arrow-left"></i> Back</a>
						</div>
					</div>
                    <div class="card-body">
                        <form class="form pt-3" method="post" action="{{url('admin/learningjernal/'.$learningjernal->id)}}">
                            @csrf
                            @method('put')

                            <div class="form-group">
                                <label>jernal Name</label>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" placeholder="name" name="name" value="{{$learningjernal->jernal_name}}">

                                    @if ($errors->has('name'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('name') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Jernal Content</label>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" placeholder="content" name="content" value="{{$learningjernal->jernal_content}}">

                                    @if ($errors->has('content'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('content') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Course Name</label>
                                <select class="form-control custom-select" name="course_name">
                                    <option>Select Course</option>
                                    @foreach($courses as $course)
                                    <option value="{{$course->id}}">{{$course->name}}</option>

                                    <option value="{{$course->id}}"{{$course->id == $learningjernal->course->id ? 'selected' : ''}}>{{$course->name}}</option>
                                    @endforeach
                                </select>
                                @if ($errors->has('course_name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('course_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-success mr-2">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
@endsection
@push('js')
<script src="{{asset('contents/admin/assets/libs/tinymce/tinymce.min.js')}}"></script>
<script>
    $(function () {
        //TinyMCE
        tinymce.init({
            selector: "#description",
            theme: "modern",
            height: 300,
            plugins: [
                'advlist autolink lists link image charmap print preview hr anchor pagebreak',
                'searchreplace wordcount visualblocks visualchars code fullscreen',
                'insertdatetime media nonbreaking save table contextmenu directionality',
                'emoticons template paste textcolor colorpicker textpattern imagetools'
            ],
            toolbar1: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
            toolbar2: 'print preview media | forecolor backcolor emoticons',
            image_advtab: true
        });
        tinymce.suffix = ".min";
        tinyMCE.baseURL = '{{ asset('contents/admin/assets/libs/tinymce') }}';
    });
</script>
@endpush

